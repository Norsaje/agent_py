#!/usr/bin/env python3
"""Lossless, local preprocessing. This script does not interpret meeting content."""
from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tempfile


HEADER = re.compile(
    r"^\s*(?P<day>\d{4}-\d{2}-\d{2})\s+"
    r"(?P<clock>\d{2}[-:]\d{2}[-:]\d{2})\s*[-–—]\s*"
    r"(?P<speaker>.*?)\s*:\s*(?P<text>.*)$"
)
HEADER_LIKE = re.compile(r"^\s*(?:\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}:\d{2})\b")
BROKEN_SPEAKER = re.compile(r"^\s*[^:]*\(распознано\)\s*:", re.IGNORECASE)
ASR_MARKER = re.compile(r"\s*\(распознано\)\s*$", re.IGNORECASE)


def prepare(raw: bytes, input_name: str, encoding: str = "utf-8-sig",
            timezone: str | None = None, kind: str = "transcript") -> dict:
    decoded = raw.decode(encoding, errors="strict")
    lines = decoded.splitlines()
    digest = hashlib.sha256(raw).hexdigest()
    result = {
        "schema_version": 1, "source_id": "s-" + digest[:16], "sha256": digest,
        "kind": kind, "timezone": timezone, "encoding": encoding,
        "input_name": input_name, "line_count": len(lines),
        "raw_lines": [{"line_no": n, "text": line} for n, line in enumerate(lines, 1)],
        "turns": [], "unparsed": [], "warnings": [],
    }
    current = None
    last_timestamp = None

    def add_unparsed(n: int, text: str, reason: str) -> None:
        result["unparsed"].append({"line_no": n, "text": text, "reason": reason})
        result["warnings"].append({"line_no": n, "code": "unparsed", "message": reason})

    def add_turn(n: int, timestamp: str | None, speaker: str, uncertain: bool,
                 text: str) -> dict:
        turn = {"id": f"t-{len(result['turns']) + 1:06d}", "line_start": n,
                "line_end": n, "timestamp_local": timestamp, "speaker": speaker,
                "speaker_asr_uncertain": uncertain, "text": text}
        result["turns"].append(turn)
        return turn

    for n, line in enumerate(lines, 1):
        if kind == "notes":
            if line.strip():
                add_turn(n, None, "Письменный источник", False, line)
            continue
        match = HEADER.match(line)
        if match:
            # A broken header is never silently appended to the preceding speaker.
            current = None
            groups = match.groupdict()
            speaker_raw = groups["speaker"].strip()
            marker = ASR_MARKER.search(speaker_raw)
            speaker = ASR_MARKER.sub("", speaker_raw).strip()
            if not speaker:
                add_unparsed(n, line, "empty speaker")
                continue
            try:
                clock = groups["clock"]
                if clock[2] != clock[5]:
                    raise ValueError("mixed time separators")
                local = datetime.strptime(groups["day"] + " " + clock.replace("-", ":"),
                                          "%Y-%m-%d %H:%M:%S")
            except ValueError:
                add_unparsed(n, line, "invalid date or time")
                continue
            if last_timestamp is not None and local < last_timestamp:
                result["warnings"].append({"line_no": n, "code": "time_regression",
                    "message": "timestamp precedes previous parsed turn; original order retained"})
            last_timestamp = local
            current = add_turn(n, local.isoformat(timespec="seconds"), speaker,
                               bool(marker), groups["text"])
            if not groups["text"].strip():
                result["warnings"].append({"line_no": n, "code": "empty_turn",
                                            "message": "speaker turn begins with empty text"})
        elif HEADER_LIKE.match(line) or BROKEN_SPEAKER.match(line):
            current = None
            add_unparsed(n, line, "malformed timestamp or speaker header")
        elif not line.strip():
            # Blank lines remain in raw_lines, and preserve paragraph breaks within a turn.
            if current is not None:
                current["text"] += "\n" + line
                current["line_end"] = n
        elif current is not None:
            current["text"] += "\n" + line
            current["line_end"] = n
        else:
            add_unparsed(n, line, "text outside a parsed speaker turn")
    return result


def write_prepared(document: dict, output: Path) -> str:
    """Idempotent import; refuse an existing path belonging to another source."""
    if output.exists():
        with output.open("r", encoding="utf-8-sig") as stream:
            previous = json.load(stream)
        keys = ("schema_version", "sha256", "kind", "timezone", "encoding")
        if not isinstance(previous, dict) or any(previous.get(k) != document.get(k) for k in keys):
            raise ValueError("output already exists for different bytes or preprocessing settings")
        if any(previous.get(k) != value for k, value in document.items() if k != "input_name"):
            raise ValueError("existing output content differs from deterministic prepared source")
        return "unchanged"
    output.parent.mkdir(parents=True, exist_ok=True)
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", newline="\n",
                                         dir=output.parent, prefix=".prepare-", suffix=".tmp",
                                         delete=False) as stream:
            temp_path = Path(stream.name)
            json.dump(document, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        # Check again before replacement to avoid overwriting a source created during parsing.
        if output.exists():
            return write_prepared(document, output)
        os.replace(temp_path, output)
        return "created"
    finally:
        if temp_path is not None and temp_path.exists():
            temp_path.unlink()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--encoding", choices=("utf-8-sig", "cp1251"), default="utf-8-sig")
    parser.add_argument("--timezone", default=None,
                        help="Known source timezone, e.g. Europe/Moscow; omitted means unknown")
    parser.add_argument("--kind", choices=("transcript", "notes"), default="transcript")
    args = parser.parse_args(argv)
    try:
        document = prepare(args.input.read_bytes(), args.input.name, args.encoding,
                           args.timezone, args.kind)
        status = write_prepared(document, args.output)
        print(json.dumps({"status": status, "file": str(args.output.resolve()),
            "source_id": document["source_id"], "turns": len(document["turns"]),
            "unparsed": len(document["unparsed"]), "warnings": len(document["warnings"])},
            ensure_ascii=True))
        return 0
    except (OSError, UnicodeError, ValueError, TypeError) as exc:
        print(json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=True))
        return 1


if __name__ == "__main__":
    sys.exit(main())
