#!/usr/bin/env python3
"""Validate local evidence, knowledge links and presentation numbers. No network calls."""
from __future__ import annotations

import argparse
from datetime import date
import json
import math
from pathlib import Path
import re
import sys


KINDS = {"fact", "decision", "action", "metric", "requirement", "risk", "question", "hypothesis"}
STATUSES = {"reported", "agreed", "proposed", "inferred", "unresolved", "disputed", "superseded", "rejected"}
ATTRIBUTIONS = {"explicit", "asr_uncertain", "contextual", "none"}
UNSAFE = {"inferred", "disputed", "unresolved", "rejected", "superseded"}
MARKERS = {"inferred": ("гипотез", "вывод", "inferred"),
           "disputed": ("спор", "disputed"),
           "unresolved": ("не реш", "открыт", "unresolved"),
           "rejected": ("отклон", "rejected"),
           "superseded": ("замен", "superseded")}


def number(value) -> bool:
    return type(value) is int or (type(value) is float and math.isfinite(value))


class Validator:
    def __init__(self):
        self.errors = []
        self.warnings = []
        self.sources = {}
        self.turns = {}
        self.entities = {}
        self.claims = {}
        self.relations = {}
        self.extraction = {}
        self.source_ids = set()

    def error(self, path, message):
        self.errors.append({"path": path, "message": message})

    def warn(self, path, message):
        self.warnings.append({"path": path, "message": message})

    def load(self, path: Path, label: str):
        try:
            def no_constant(value):
                raise ValueError(f"non-finite JSON number: {value}")
            with path.open("r", encoding="utf-8-sig") as stream:
                value = json.load(stream, parse_constant=no_constant)
            if not isinstance(value, dict):
                self.error(label, "top-level JSON must be an object")
                return None
            return value
        except (OSError, UnicodeError, ValueError, TypeError) as exc:
            self.error(label, f"cannot read JSON: {exc}")
            return None

    def required(self, obj, keys, path):
        for key in keys:
            if key not in obj:
                self.error(f"{path}.{key}", "required field is missing")

    def string(self, value, path, nullable=False):
        if value is None and nullable:
            return True
        if not isinstance(value, str) or not value.strip():
            self.error(path, "must be a nonempty string" + (" or null" if nullable else ""))
            return False
        return True

    def enum(self, value, options, path):
        if not isinstance(value, str) or value not in options:
            self.error(path, "must be one of: " + ", ".join(sorted(options)))
            return False
        return True

    def array(self, value, path):
        if not isinstance(value, list):
            self.error(path, "must be an array")
            return []
        return value

    def strings(self, value, path):
        values = self.array(value, path)
        valid = []
        for i, item in enumerate(values):
            if self.string(item, f"{path}[{i}]"):
                valid.append(item)
        if len(set(valid)) != len(valid):
            self.error(path, "duplicate IDs or names")
        return valid

    def iso_date(self, value, path):
        if value is None:
            return
        if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
            self.error(path, "must be null or an ISO date YYYY-MM-DD")
            return
        try:
            date.fromisoformat(value)
        except ValueError:
            self.error(path, "invalid calendar date")

    def version(self, obj, path):
        if type(obj.get("schema_version")) is not int or obj.get("schema_version") != 1:
            self.error(path + ".schema_version", "must be integer 1")

    def add_source(self, source, label):
        self.version(source, label)
        sid = source.get("source_id")
        if not self.string(sid, label + ".source_id"):
            return
        digest = source.get("sha256")
        if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
            self.error(label + ".sha256", "must be a SHA-256 hex digest")
        elif sid != "s-" + digest[:16]:
            self.error(label + ".source_id", "does not match SHA-256 prefix")
        if sid in self.sources:
            if self.sources[sid] != source:
                self.error(label, "same source ID has different prepared content")
            return
        self.sources[sid] = source
        seen = set()
        for i, turn in enumerate(self.array(source.get("turns"), label + ".turns")):
            p = f"{label}.turns[{i}]"
            if not isinstance(turn, dict):
                self.error(p, "turn must be an object")
                continue
            tid = turn.get("id")
            if not self.string(tid, p + ".id"):
                continue
            if tid in seen:
                self.error(p + ".id", "duplicate turn ID in source")
                continue
            seen.add(tid)
            if not isinstance(turn.get("text"), str):
                self.error(p + ".text", "must be a string")
            if type(turn.get("speaker_asr_uncertain")) is not bool:
                self.error(p + ".speaker_asr_uncertain", "must be boolean")
            self.string(turn.get("speaker"), p + ".speaker")
            self.turns[(sid, tid)] = turn
        if source.get("unparsed"):
            self.warn(label + ".unparsed", "source contains unparsed lines; review them before extraction")

    def index(self, rows, kind, target, path, historical=False):
        result = []
        seen = set()
        for i, obj in enumerate(self.array(rows, path)):
            p = f"{path}[{i}]"
            if not isinstance(obj, dict):
                self.error(p, f"{kind} must be an object")
                continue
            identity = obj.get("id")
            if not self.string(identity, p + ".id"):
                continue
            if identity in seen:
                self.error(p + ".id", f"duplicate {kind} ID")
                continue
            seen.add(identity)
            for other in (self.entities, self.claims, self.relations):
                if other is not target and identity in other:
                    self.error(p + ".id", "ID collides with another object type")
            if identity in target and not historical:
                old = target[identity]
                if kind == "entity":
                    if obj.get("type") != old.get("type") or obj.get("name") != old.get("name"):
                        self.error(p + ".id", "historical entity type/name cannot change; add an alias instead")
                elif obj != old:
                    self.error(p + ".id", "historical object cannot be changed in place; use a new ID")
            target[identity] = obj
            result.append((obj, p))
        return result

    def evidence(self, rows, path, require=False, source_coverage=True):
        values = self.array(rows, path)
        if require and not values:
            self.error(path, "at least one exact source quotation is required")
        referenced_turns = []
        for i, ev in enumerate(values):
            p = f"{path}[{i}]"
            if not isinstance(ev, dict):
                self.error(p, "evidence must be an object")
                continue
            self.required(ev, ("source_id", "turn_id", "quote"), p)
            sid, tid, quote = ev.get("source_id"), ev.get("turn_id"), ev.get("quote")
            sid_ok = self.string(sid, p + ".source_id")
            tid_ok = self.string(tid, p + ".turn_id")
            quote_ok = self.string(quote, p + ".quote")
            if not (sid_ok and tid_ok):
                continue
            if source_coverage and sid not in self.source_ids:
                self.error(p + ".source_id", "evidence source is missing from extraction.source_ids")
            turn = self.turns.get((sid, tid))
            if turn is None:
                self.error(p, "source/turn reference does not exist among supplied sources")
                continue
            referenced_turns.append(turn)
            if quote_ok and (not isinstance(turn.get("text"), str) or quote not in turn["text"]):
                self.error(p + ".quote", "quotation is not an exact substring of referenced turn.text")
        return referenced_turns

    def validate_entity(self, obj, p):
        self.required(obj, ("id", "type", "name", "aliases"), p)
        self.string(obj.get("type"), p + ".type")
        self.string(obj.get("name"), p + ".name")
        self.strings(obj.get("aliases"), p + ".aliases")

    def validate_metric(self, metric, p):
        if not isinstance(metric, dict):
            self.error(p, "must be a metric object")
            return
        self.required(metric, ("value", "unit", "period", "definition", "qualifier"), p)
        if metric.get("value") is None:
            self.warn(p + ".value", "metric value is unknown or unmeasured; do not invent a number")
        elif not number(metric.get("value")):
            self.error(p + ".value", "must be a finite JSON number or null")
        for key in ("unit", "period", "definition", "qualifier"):
            self.string(metric.get(key), p + "." + key, nullable=True)
            if key != "qualifier" and metric.get(key) is None:
                self.warn(p + "." + key, "unknown metric context; do not invent it")

    def validate_claim(self, obj, p):
        if "confidence" in obj:
            self.error(p + ".confidence", "probabilistic confidence is not part of this evidence schema")
        self.required(obj, ("id", "kind", "text", "status", "evidence", "entity_ids", "owner",
                            "due_date", "valid_from", "valid_to", "attribution", "rationale",
                            "supersedes", "conflicts_with", "metric"), p)
        self.enum(obj.get("kind"), KINDS, p + ".kind")
        self.enum(obj.get("status"), STATUSES, p + ".status")
        self.enum(obj.get("attribution"), ATTRIBUTIONS, p + ".attribution")
        self.string(obj.get("text"), p + ".text")
        self.string(obj.get("rationale"), p + ".rationale", nullable=True)
        turns = self.evidence(obj.get("evidence"), p + ".evidence", require=True)
        for eid in self.strings(obj.get("entity_ids"), p + ".entity_ids"):
            if eid not in self.entities:
                self.error(p + ".entity_ids", f"unknown entity ID {eid}")
        for key in ("due_date", "valid_from", "valid_to"):
            self.iso_date(obj.get(key), p + "." + key)
        start, end = obj.get("valid_from"), obj.get("valid_to")
        if isinstance(start, str) and isinstance(end, str) and start > end:
            self.error(p + ".valid_to", "valid_to precedes valid_from")
        owner = obj.get("owner")
        if owner is not None and self.string(owner, p + ".owner"):
            entity = self.entities.get(owner)
            if entity is None:
                self.error(p + ".owner", "owner must reference an existing entity")
            elif entity.get("type") not in ("person", "team"):
                self.error(p + ".owner", "owner must be a person or team entity")
            elif entity.get("type") == "person":
                names = [entity.get("name")] + (entity.get("aliases") if isinstance(entity.get("aliases"), list) else [])
                names = {name.casefold().strip() for name in names if isinstance(name, str)}
                uncertain_owner = any(t.get("speaker_asr_uncertain") is True and
                    isinstance(t.get("speaker"), str) and t["speaker"].casefold().strip() in names for t in turns)
                other_evidence = any(t.get("speaker_asr_uncertain") is False for t in turns)
                # A named assignee inside the quotation is independent of the ASR speaker label.
                # This is only a lexical check; the agent must still assess the surrounding meaning.
                evidence_rows = obj.get("evidence") if isinstance(obj.get("evidence"), list) else []
                quoted_names = any(isinstance(ev, dict) and isinstance(ev.get("quote"), str)
                    and any(name in ev["quote"].casefold() for name in names)
                    for ev in evidence_rows)
                if uncertain_owner and not other_evidence and not quoted_names:
                    if obj.get("attribution") == "explicit" or obj.get("status") == "agreed":
                        self.error(p + ".owner", "ASR-uncertain speaker identity cannot establish this owner without other evidence")
                    else:
                        self.warn(p + ".owner", "owner identity remains uncertain; request confirmation")
        if obj.get("kind") == "hypothesis":
            if obj.get("status") not in ("inferred", "proposed"):
                self.error(p + ".status", "hypothesis must be inferred or proposed")
            self.string(obj.get("rationale"), p + ".rationale")
        if obj.get("status") == "inferred":
            self.string(obj.get("rationale"), p + ".rationale")
        if obj.get("kind") == "decision" and obj.get("status") == "agreed" and obj.get("attribution") != "explicit":
            self.error(p + ".attribution", "agreed decision requires explicit attribution")
        if obj.get("attribution") == "asr_uncertain" and turns and not any(t.get("speaker_asr_uncertain") is True for t in turns):
            self.warn(p + ".attribution", "ASR uncertainty label has no uncertain speaker in quoted evidence")
        for key in ("supersedes", "conflicts_with"):
            references = self.strings(obj.get(key), p + "." + key)
            if key == "supersedes" and references and (obj.get("status") != "agreed" or obj.get("attribution") != "explicit"):
                self.error(p + ".supersedes", "supersedes requires an agreed claim with explicit attribution")
            for cid in references:
                if cid == obj.get("id"):
                    self.error(p + "." + key, "claim cannot reference itself")
                elif cid not in self.claims:
                    self.error(p + "." + key, f"unknown claim ID {cid}; supply historical knowledge if needed")
        metric = obj.get("metric")
        if obj.get("kind") == "metric" and metric is None:
            self.error(p + ".metric", "metric claim requires a metric object")
        elif metric is not None:
            self.validate_metric(metric, p + ".metric")

    def validate_relation(self, obj, p):
        self.required(obj, ("id", "subject_id", "predicate", "object_id", "claim_ids", "evidence"), p)
        for key in ("subject_id", "object_id"):
            value = obj.get(key)
            if self.string(value, p + "." + key) and value not in self.entities and value not in self.claims:
                self.error(p + "." + key, "endpoint must reference an entity or claim")
        self.string(obj.get("predicate"), p + ".predicate")
        cids = self.strings(obj.get("claim_ids"), p + ".claim_ids")
        for cid in cids:
            if cid not in self.claims:
                self.error(p + ".claim_ids", f"unknown claim ID {cid}")
        self.evidence(obj.get("evidence"), p + ".evidence")
        if not cids and not obj.get("evidence"):
            self.error(p, "relation requires supporting claim_ids or exact evidence")

    def validate_extraction(self, extraction, knowledge=None):
        self.extraction = extraction
        p = "extraction"
        self.version(extraction, p)
        self.required(extraction, ("schema_version", "project_id", "run_id", "source_ids", "entities", "claims", "relations"), p)
        self.string(extraction.get("project_id"), p + ".project_id")
        self.string(extraction.get("run_id"), p + ".run_id")
        self.source_ids = set(self.strings(extraction.get("source_ids"), p + ".source_ids"))
        for sid in self.source_ids:
            if sid not in self.sources:
                self.error(p + ".source_ids", f"source {sid} was not supplied")
        if knowledge is not None:
            if self.string(knowledge.get("project_id"), "knowledge.project_id") and knowledge.get("project_id") != extraction.get("project_id"):
                self.error("knowledge.project_id", "must match extraction.project_id")
            for name, target in (("entities", self.entities), ("claims", self.claims), ("relations", self.relations)):
                self.index(knowledge.get(name), name[:-1] if name != "entities" else "entity",
                           target, "knowledge." + name, historical=True)
        entities = self.index(extraction.get("entities"), "entity", self.entities, p + ".entities")
        claims = self.index(extraction.get("claims"), "claim", self.claims, p + ".claims")
        relations = self.index(extraction.get("relations"), "relation", self.relations, p + ".relations")
        for obj, path in entities:
            self.validate_entity(obj, path)
        for obj, path in claims:
            self.validate_claim(obj, path)
        for obj, path in relations:
            self.validate_relation(obj, path)
        self.validate_supersedes_graph()

    def validate_supersedes_graph(self):
        """Inspect immutable history and new records together, without recursion limits."""
        graph = {cid: [target for target in claim.get("supersedes", [])
                       if isinstance(target, str) and target in self.claims]
                 for cid, claim in self.claims.items() if isinstance(claim.get("supersedes"), list)}
        colors = {}
        for start in graph:
            if colors.get(start, 0):
                continue
            colors[start] = 1
            stack = [(start, iter(graph.get(start, [])))]
            while stack:
                current, edges = stack[-1]
                target = next(edges, None)
                if target is None:
                    colors[current] = 2
                    stack.pop()
                elif colors.get(target, 0) == 1:
                    self.error("claims.supersedes", f"supersedes cycle detected at {current} -> {target}")
                elif colors.get(target, 0) == 0:
                    colors[target] = 1
                    stack.append((target, iter(graph.get(target, []))))

    def validate_brief(self, brief):
        p = "brief"
        self.version(brief, p)
        self.required(brief, ("schema_version", "project_id", "run_id", "audience", "classification", "output_path",
                              "slides", "excluded_claim_ids", "status", "pptx_skill_path"), p)
        for key in ("project_id", "run_id"):
            if self.string(brief.get(key), p + "." + key) and brief.get(key) != self.extraction.get(key):
                self.error(p + "." + key, "must match extraction")
        self.enum(brief.get("audience"), {"internal", "executive", "client"}, p + ".audience")
        self.enum(brief.get("classification"), {"internal", "client_safe"}, p + ".classification")
        self.enum(brief.get("status"), {"draft", "ready"}, p + ".status")
        self.string(brief.get("output_path"), p + ".output_path")
        self.string(brief.get("pptx_skill_path"), p + ".pptx_skill_path")
        if brief.get("audience") == "client" and brief.get("classification") != "client_safe":
            self.error(p + ".classification", "client audience requires client_safe classification")
        client = brief.get("audience") == "client" or brief.get("classification") == "client_safe"
        superseded_ids = {cid for claim in self.claims.values()
                          if claim.get("status") == "agreed" and claim.get("attribution") == "explicit"
                          and isinstance(claim.get("supersedes"), list)
                          for cid in claim["supersedes"] if isinstance(cid, str)}
        excluded = set(self.strings(brief.get("excluded_claim_ids"), p + ".excluded_claim_ids"))
        for cid in excluded:
            if cid not in self.claims:
                self.error(p + ".excluded_claim_ids", f"unknown claim ID {cid}")
        slide_ids = set()
        for i, slide in enumerate(self.array(brief.get("slides"), p + ".slides")):
            sp = f"{p}.slides[{i}]"
            if not isinstance(slide, dict):
                self.error(sp, "slide must be an object")
                continue
            self.required(slide, ("id", "title", "claim_ids", "bullets", "notes", "chart"), sp)
            sid = slide.get("id")
            if self.string(sid, sp + ".id"):
                if sid in slide_ids:
                    self.error(sp + ".id", "duplicate slide ID")
                slide_ids.add(sid)
            self.string(slide.get("title"), sp + ".title")
            bullets = self.strings(slide.get("bullets"), sp + ".bullets")
            notes = slide.get("notes")
            if not isinstance(notes, str):
                self.error(sp + ".notes", "must be a string")
                notes = ""
            cids = self.strings(slide.get("claim_ids"), sp + ".claim_ids")
            if bullets and not cids:
                self.warn(sp + ".claim_ids", "slide bullets have no linked claims; verify this is only framing")
            for cid in cids:
                claim = self.claims.get(cid)
                if claim is None:
                    self.error(sp + ".claim_ids", f"unknown claim ID {cid}")
                    continue
                if cid in excluded:
                    self.error(sp + ".claim_ids", f"claim {cid} is also explicitly excluded")
                # Historical records are immutable. A newer claim can supersede an old ID
                # without rewriting the original historical status.
                status = "superseded" if cid in superseded_ids else claim.get("status")
                if isinstance(status, str) and status in UNSAFE:
                    if client:
                        self.error(sp + ".claim_ids", f"{status} claim {cid} cannot appear on client_safe slides")
                    elif not any(marker in notes.casefold() for marker in MARKERS[status]):
                        self.error(sp + ".notes", f"label {status} claim {cid} explicitly in speaker notes")
                metric = claim.get("metric")
                if client and isinstance(metric, dict) and number(metric.get("value")) and any(metric.get(k) is None for k in ("unit", "period", "definition")):
                    self.error(sp + ".claim_ids", f"metric {cid} has incomplete unit/period/definition for a client presentation")
            chart = slide.get("chart")
            if chart is not None:
                self.validate_chart(chart, sp + ".chart", cids)

    def validate_chart(self, chart, p, slide_claim_ids):
        if not isinstance(chart, dict):
            self.error(p, "chart must be null or an object")
            return
        self.required(chart, ("title", "unit", "period", "definition", "data"), p)
        self.string(chart.get("title"), p + ".title")
        for key in ("unit", "period", "definition"):
            self.string(chart.get(key), p + "." + key, nullable=True)
        rows = self.array(chart.get("data"), p + ".data")
        if not rows:
            self.error(p + ".data", "chart requires at least one data point")
        for i, point in enumerate(rows):
            pp = f"{p}.data[{i}]"
            if not isinstance(point, dict):
                self.error(pp, "data point must be an object")
                continue
            self.required(point, ("label", "value", "claim_id"), pp)
            self.string(point.get("label"), pp + ".label")
            valid_number = number(point.get("value"))
            if not valid_number:
                self.error(pp + ".value", "must be a finite JSON number")
            cid = point.get("claim_id")
            if not self.string(cid, pp + ".claim_id"):
                continue
            if cid not in slide_claim_ids:
                self.error(pp + ".claim_id", "chart claim must also be in slide.claim_ids")
            claim = self.claims.get(cid)
            if claim is None:
                self.error(pp + ".claim_id", "unknown claim ID")
                continue
            metric = claim.get("metric")
            if claim.get("kind") != "metric" or not isinstance(metric, dict):
                self.error(pp + ".claim_id", "chart must reference a metric claim")
                continue
            if valid_number and (not number(metric.get("value")) or point["value"] != metric["value"]):
                self.error(pp + ".value", "chart value differs from referenced metric.value")
            for key in ("unit", "period", "definition"):
                if chart.get(key) != metric.get(key):
                    self.error(p + "." + key, f"chart context differs from metric {cid}")

    def result(self):
        return {"valid": not self.errors, "errors": self.errors, "warnings": self.warnings,
                "counts": {"sources": len(self.sources), "turns": len(self.turns),
                           "entities": len(self.entities), "claims": len(self.claims),
                           "relations": len(self.relations)}}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--extraction", required=True, type=Path)
    parser.add_argument("--source", action="append", default=[], type=Path)
    parser.add_argument("--source-dir", type=Path)
    parser.add_argument("--brief", type=Path)
    parser.add_argument("--knowledge", type=Path)
    args = parser.parse_args(argv)
    validator = Validator()
    try:
        paths = list(args.source)
        if args.source_dir:
            if not args.source_dir.is_dir():
                validator.error("sources", "source-dir is not a readable directory")
            else:
                paths.extend(sorted(args.source_dir.rglob("*.json")))
        seen_paths = set()
        for path in paths:
            absolute = path.resolve()
            if absolute in seen_paths:
                continue
            seen_paths.add(absolute)
            source = validator.load(path, "source:" + str(path))
            if source is not None:
                validator.add_source(source, "source:" + str(path))
        extraction = validator.load(args.extraction, "extraction")
        knowledge = validator.load(args.knowledge, "knowledge") if args.knowledge else None
        if extraction is not None:
            validator.validate_extraction(extraction, knowledge)
            if args.brief:
                brief = validator.load(args.brief, "brief")
                if brief is not None:
                    validator.validate_brief(brief)
        elif args.brief:
            validator.warn("brief", "brief validation skipped because extraction is unreadable")
    except (OSError, ValueError, TypeError, KeyError, AttributeError, OverflowError, RecursionError) as exc:
        # Defensive CLI boundary: malformed values produce JSON diagnostics, never a traceback.
        validator.error("validation", f"cannot validate malformed document: {exc}")
    result = validator.result()
    print(json.dumps(result, ensure_ascii=True, allow_nan=False))
    return 0 if result["valid"] else 1


if __name__ == "__main__":
    sys.exit(main())
