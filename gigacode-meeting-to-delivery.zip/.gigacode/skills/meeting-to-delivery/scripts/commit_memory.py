#!/usr/bin/env python3
"""Validate and append meeting observations to immutable local snapshots. No network."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile


def canonical(value: object) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def read_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object: {path.name}")
    return value


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix=".pending-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def merge_items(old: list, new: list, entities: bool = False) -> list:
    merged = {item["id"]: dict(item) for item in old}
    for item in new:
        item_id = item["id"]
        if item_id not in merged:
            merged[item_id] = dict(item)
            continue
        previous = merged[item_id]
        if entities:
            if previous["type"] != item["type"] or previous["name"] != item["name"]:
                raise ValueError(f"Existing entity cannot change identity: {item_id}")
            previous["aliases"] = sorted(set(previous["aliases"]) | set(item["aliases"]))
        elif canonical(previous) != canonical(item):
            raise ValueError(f"Existing observation is immutable; use a new ID: {item_id}")
    return [merged[key] for key in sorted(merged)]


def commit(args: argparse.Namespace) -> dict:
    workspace = Path(args.workspace).resolve()
    extraction_path = Path(args.extraction).resolve()
    extraction = read_json(extraction_path)
    project_id = extraction.get("project_id")
    if not isinstance(project_id, str) or not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", project_id):
        raise ValueError("project_id must be a lowercase project slug")
    if workspace.name != project_id:
        raise ValueError("workspace directory name must equal extraction.project_id")
    if not isinstance(extraction.get("run_id"), str) or not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9-]*", extraction["run_id"]):
        raise ValueError("run_id must contain only letters, digits and hyphens")
    digest = hashlib.sha256(canonical(extraction)).hexdigest()
    memory = workspace / "memory"
    memory.mkdir(parents=True, exist_ok=True)
    lock = memory / ".write.lock"
    try:
        lock_fd = os.open(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        raise ValueError("Memory writer lock exists; check active writer before retrying") from None
    try:
        with os.fdopen(lock_fd, "w", encoding="utf-8") as handle:
            handle.write(str(os.getpid()))
        pointer = memory / "CURRENT"
        current = pointer.read_text(encoding="utf-8").strip() if pointer.exists() else "empty"
        snapshot_path = None
        if current != "empty":
            if not re.fullmatch(r"rev-[0-9a-f]{20}", current):
                raise ValueError("Invalid CURRENT pointer")
            snapshot_path = memory / "snapshots" / f"{current}.json"
            old = read_json(snapshot_path)
            if old.get("revision") != current or old.get("project_id") != project_id:
                raise ValueError("Snapshot identity does not match CURRENT/project")
            content = dict(old)
            content.pop("revision", None)
            if "rev-" + hashlib.sha256(canonical(content)).hexdigest()[:20] != current:
                raise ValueError("Snapshot hash mismatch; inspect memory integrity")
        else:
            old = {"entities": [], "claims": [], "relations": [], "source_ids": [], "commits": []}
        for receipt in old.get("commits", []):
            if receipt["run_id"] == extraction["run_id"]:
                if receipt["extraction_sha256"] == digest:
                    return {"status": "already_committed", "revision": current, "run_id": extraction["run_id"]}
                raise ValueError("run_id was committed with different content; create a corrective run")
        if args.base != current:
            raise ValueError(f"Memory changed: expected base {args.base}, current {current}; reread and reconcile")
        command = [sys.executable, str(Path(__file__).with_name("validate_run.py")),
                   "--extraction", str(extraction_path), "--source-dir", str(workspace / "sources")]
        if snapshot_path:
            command.extend(["--knowledge", str(snapshot_path)])
        completed = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="strict", timeout=120,
                                   env={**os.environ, "PYTHONIOENCODING": "utf-8"})
        try:
            validation = json.loads(completed.stdout)
        except json.JSONDecodeError:
            raise ValueError("Validator failed to return JSON; memory unchanged") from None
        if completed.returncode != 0 or validation.get("valid") is not True:
            return {"status": "validation_failed", "validation": validation}
        payload = {
            "schema_version": 1, "project_id": project_id, "parent_revision": current,
            "run_id": extraction["run_id"],
            "source_ids": sorted(set(old["source_ids"]) | set(extraction["source_ids"])),
            "entities": merge_items(old["entities"], extraction["entities"], entities=True),
            "claims": merge_items(old["claims"], extraction["claims"]),
            "relations": merge_items(old["relations"], extraction["relations"]),
            "commits": [*old.get("commits", []), {"run_id": extraction["run_id"], "extraction_sha256": digest}],
        }
        revision = "rev-" + hashlib.sha256(canonical(payload)).hexdigest()[:20]
        payload["revision"] = revision
        target = memory / "snapshots" / f"{revision}.json"
        if target.exists():
            if canonical(read_json(target)) != canonical(payload):
                raise ValueError("Existing snapshot differs; memory unchanged")
        else:
            atomic_write(target, json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False).encode("utf-8") + b"\n")
        atomic_write(pointer, (revision + "\n").encode("utf-8"))
        return {"status": "committed", "revision": revision, "parent_revision": current,
                "run_id": extraction["run_id"], "counts": {key: len(payload[key]) for key in ("source_ids", "entities", "claims", "relations")},
                "warnings": validation.get("warnings", [])}
    finally:
        lock.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", required=True, help="Project directory ending in project_id")
    parser.add_argument("--extraction", required=True)
    parser.add_argument("--base", required=True, help="CURRENT revision, or empty for first commit")
    args = parser.parse_args()
    try:
        result = commit(args)
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
        result = {"status": "error", "message": str(error)}
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    return 0 if result["status"] in {"committed", "already_committed"} else 1


if __name__ == "__main__":
    sys.exit(main())
