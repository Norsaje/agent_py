# Доказательства, граф знаний и история

## Модель хранения

Это переносимый граф в JSON: entities → claims → relations → источники. Он не требует Neo4j, векторной БД или MCP. Объектный граф удобен для поиска зависимостей и объяснения происхождения; семантическое сопоставление выполняет агент. Не называй его обученным GraphRAG или автономным сервисом.

Три разных времени: `timestamp_local` реплики, `valid_from/valid_to` утверждения и время run. Более позднее упоминание старого события не создаёт новую версию события. Без доказательства времени действия используй null. Для метрики период хранится внутри metric. Поле due_date означает срок действия, а не дату созвона.

## Контракт extraction.json, schema_version = 1

Обязательные верхние поля: `schema_version`, `project_id`, `run_id`, `source_ids`, `entities`, `claims`, `relations`. Пустые списки допустимы, если сведений нет. Сохранённое наблюдение — утверждение из источника с квалификатором, а не объективная истина.

| Объект | Поля |
|---|---|
| entity | id, type, name, aliases |
| claim | id, kind, text, status, evidence, entity_ids, owner, due_date, valid_from, valid_to, attribution, rationale, supersedes, conflicts_with, metric |
| evidence | source_id, turn_id, quote |
| relation | id, subject_id, predicate, object_id, claim_ids, evidence |

Типы entity: `person`, `team`, `project`, `feature`, `metric`, `artifact`. Используй стабильные IDs `e-<slug>`. Для неизвестного участника отдельный ID с неопределённой атрибуцией; не объединяй «Алексей» и «Алексей Смирнов» только по имени. Entity aliases могут расширяться при проверенной идентичности; разные люди с одинаковым именем остаются разными сущностями.

Claim IDs: `c-<source-hash8>-<sequence>`; relation IDs: `r-<source-hash8>-<sequence>`. Перед созданием ищи тот же смысл и доказательство в памяти. Ссылку на прежний claim сохраняй с прежним ID и содержимым. Для нового evidence/статуса создавай новый claim, связывай с предыдущим; история утверждений неизменяема.

`kind`: `fact`, `decision`, `action`, `metric`, `requirement`, `risk`, `question`, `hypothesis`.

`status`: `reported`, `agreed`, `proposed`, `inferred`, `unresolved`, `disputed`, `superseded`, `rejected`.

`attribution`: `explicit`, `asr_uncertain`, `contextual`, `none`. Это качество атрибуции исполнителя/решения, а не вероятность истинности. Не генерируй численный confidence. Сохраняй null для неизвестных owner/date/rationale/metric; пустые массивы для отсутствующих связей. owner — ID person/team, а не строка ФИО. Если нужен статус завершённости action, создай отдельный fact с доказательством завершения и relation `completes`; agreed не означает completed.

Каждый claim содержит хотя бы одно evidence: точный непустой фрагмент текста соответствующего turn. Любые прежние источники evidence должны быть доступны через sources. Отчёт показывает также timestamp_local и line_start/end из нормализованного источника. У гипотезы status inferred/proposed, rationale объясняет логическую цепочку, альтернативу и проверку. Причинный вывод из корреляции не подтверждён.

Metric object: `value` (число либо null), `unit`, `period`, `definition`, `qualifier` (строки либо null). Например value 0.72, unit `macro-F1 (0..1)`, period `2026-09 offline holdout`, definition `macro-average F1 по классам обращений на зафиксированном holdout`, qualifier `reported; результат CatBoost, не online KPI`. Если известно 72%, сохраняй исходную единицу; конверсию обоснуй и подпиши. Метрики с неизвестной выборкой/периодом не годятся для уверенного клиентского сравнения. Значение не обязано быть измерением: target отмечай в qualifier и не выдавай за attained.

Relations связывают entity/claim IDs; predicate — понятная связь: `depends_on`, `owns`, `measures`, `blocks`, `supports`, `contradicts`, `supersedes`, `completes`, `implements`. Evidence и claim_ids объясняют связь. Не создавай causal edge по совместному упоминанию.

## Согласование и конфликты

- «Предлагаю 15 октября» → proposed, не due_date утверждённого релиза.
- «Утверждаю релиз 22 октября как владелец» → agreed с цитатой полномочия; отдельно сохрани различие от прежнего предложения.
- «Иванов подготовит отчёт; Иванов подтвердил» → agreed action с explicit owner. «Я сделаю» у speaker с `(распознано)` → обязательство с asr_uncertain, owner null до проверки личности.
- Если две реплики противоречат, создай новые claims и conflicts_with; в результате покажи оба источника. Не выбирай последнюю просто по timestamp.
- `supersedes` допустим лишь при явной замене того же решения/требования уполномоченным решением или прямом уточнении пользователя. Для изменения одного предложения другим достаточно связи и текста delta; не изобретай прежде утверждённый baseline.

Текущая проекция для результата учитывает supersedes только из agreed claims с explicit attribution и проверенным правом замещения. Старый claim физически остаётся в снимках и может по-прежнему иметь historical status agreed; покажи его как «заменён» через связь. Неподтверждённые гипотезы никогда не заменяют действующие решения.

## Проверка

```powershell
python .gigacode/skills/meeting-to-delivery/scripts/validate_run.py --extraction ".meeting-to-delivery/projects/analytics-pilot/runs/RUN/extraction.json" --source-dir ".meeting-to-delivery/projects/analytics-pilot/sources" --knowledge ".meeting-to-delivery/projects/analytics-pilot/memory/snapshots/REVISION.json"
```

При первом запуске опусти `--knowledge`. Для презентации добавь `--brief <presentation-brief.json>`. Результат JSON сохрани в validation.json. Скрипт проверяет ссылки, типы, даты, существование цитат, исторические IDs, атрибуцию и совпадение графиков с числовыми claims. Он не доказывает entailment тезиса цитатой, полномочие speaker или отсутствие чувствительных данных в свободном тексте: сделай эти проверки смыслом.

## Запись памяти

На входе зафиксируй текущую revision из `memory/CURRENT`, либо `empty`. После подготовки и смысловой проверки записывай наблюдения; пользователь уже запросил обработку. Не спрашивай разрешение на каждое локальное добавление. Подтверждение спорных решений запрашивай отдельно, оно не мешает сохранить их как disputed/proposed.

```powershell
python .gigacode/skills/meeting-to-delivery/scripts/commit_memory.py --workspace ".meeting-to-delivery/projects/analytics-pilot" --extraction ".meeting-to-delivery/projects/analytics-pilot/runs/RUN/extraction.json" --base empty
```

Повторные запуски вместо empty получают сохранённую revision. Скрипт вызывает валидатор с источниками workspace и текущим снимком, проверяет project_id, сохраняет неизменяемый snapshot и атомарно переключает CURRENT. Для точного повторения того же run и extraction вернёт already_committed. Новые claims/relations добавляются; существующие claims/relations не переписываются. Entity aliases объединяются при том же type/name. Lock запрещает параллельную запись, --base предотвращает потерю изменений другого run. Сбой до переключения CURRENT оставляет прежнюю голову; оставшийся snapshot не считается применённым.

Для отмены ошибочного наблюдения предпочтительно создай corrective run с причиной и ссылкой на прежний claim. При действительно нужном возврате головы делай это только по запросу владельца, сохраняй snapshots и журнал причины. Не удаляй источники и не очищай stale lock автоматически, пока не проверено отсутствие работающего writer.
