# Пример результата

Это изолированное демо на двух **вымышленных** встречах. Вторая датирована 3 октября 2026 — будущей датой относительно подготовки пакета 2 октября. Пример показывает обработку последовательности источников и не является статусом реального проекта.

Начните с [статуса](report.md), затем посмотрите [дельту](delta.md), [ТЗ для DS](ds-spec.md) и [brief презентации](presentation-brief.json). Подробные основания вынесены в [evidence.md](evidence.md). [Handoff](pptx-handoff.md) показывает вход для существующего PPTX skill. Сам PPTX в демо не создан: пользовательский renderer не предоставлен.

В `openspec/changes/define-support-pilot-contract` — конкретный черновик изменения требований. Он не реализован и не архивирован; OpenSpec CLI в среде проверки отсутствовал.

Для повторения проверки на другом устройстве из корня распакованного архива:

```text
python .gigacode/skills/meeting-to-delivery/scripts/validate_run.py --extraction demo/extraction.json --source-dir demo/sources --knowledge demo/history-base.json --brief demo/presentation-brief.json
```

Ожидаемый результат: valid=true, без errors/warnings; 2 источника, 24 реплики, 26 claims и 9 relations. Команда только читает данные. Python 3.10+ нужен на целевом устройстве.

Демо оставьте в распакованном архиве. Для установки копируйте только `.gigacode/skills/meeting-to-delivery`; примеры памяти не переносите в рабочую базу проекта. Исходные синтетические транскрибации включены в `assets/examples` самого skill.
