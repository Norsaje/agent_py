"""Compatibility entry point for the Audit Insight CLI."""
import sys
from pathlib import Path


SOURCE_ROOT = Path(__file__).resolve().parents[1] / "src"
if str(SOURCE_ROOT) not in sys.path:
    sys.path.insert(0, str(SOURCE_ROOT))

from audit_insight_agent.cli import main

if __name__ == "__main__":
    main()
